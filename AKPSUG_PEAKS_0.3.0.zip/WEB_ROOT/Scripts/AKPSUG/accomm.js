define(['angular', 'components/shared/index'], function (angular) {

    /*Create module. peaksApp must match name in html file*/
    var peaksApp = angular.module('peaksApp', ['powerSchoolModule']);

    //This will create a controller which will be used in our app
    peaksApp.controller('peaksCont', function ($scope, getService) {

        $scope.settingList = [];

        loadingDialog();

        getService.getData('/admin/students/PEAKS/settings.json').then(function (retData) {
            retData.pop();
            $scope.settingList = retData;
            $scope.mode = settingList[0].testtype;
            $scope.dcid = settingList[0].dcid;
            $scope.student_number = settingList[0].student_number;
            closeLoading();
        });
        
        $scope.checkType = function () {

            $scope.mode = $j('#testtype').val();
                                  
        };

    }); //Close controller

    
    peaksApp.factory('getService', function ($http) {
        return {
            getData: function (dataFile) {
                //Return promise directly
                return $http.get(dataFile).then(function (result) {
                    return result.data;
                });
            }
        };
    }); //Close Factory

}); //Close define