define(['angular', 'components/shared/index'], function (angular) {

    /*Create module. peaksApp must match name in html file*/
    var peaksApp = angular.module('peaksApp', ['powerSchoolModule']);

    //This will create a controller which will be used in our app
    peaksApp.controller('peaksCont', function ($scope, getService) {

        $scope.override = false;
        $scope.ELAReason = true;
        $scope.MAReason = true;
        $scope.warning = '';

        loadingDialog();

        getService.getData('/admin/students/AKSTAR/schools.json?').then(function (retData) {          
            $scope.schools = retData.data;
            closeLoading();
        });
        
        $scope.testOverride = function () {
            
            if ($j('#elaOverride').val() === 'N') {
                $scope.override = true;
                $scope.ELAReason = false;
                if ($j('#elaReason').val().length < 3) {
                    $scope.warning = 'You must select a reason why the student is not participating in an assessment.';
                }
            }
            if ($j('#maOverride').val() === 'N') {
                $scope.override = true;
                $scope.ELAReason = false;
                if ($j('#maReason').val().length < 3) {
                    $scope.warning = 'You must select a reason why the student is not participating in an assessment.';
                }
            }
            if ($j('#elaOverride').val() !== 'N' && $j('#maOverride').val() !== 'N') {
                $scope.override = false;
                $scope.ELAReason = true;
                $scope.MAReason = true
                $scope.warning = '';
                $j('#elaReason').val('');
                $j('#maReason').val('');
            }
            
        };

    }); //Close controller
        
    peaksApp.factory('getService', function ($http) {
        return {
            getData: function (dataFile) {
                //Return promise directly
                return $http.get(dataFile).then(function (result) {
                    return result.data;
                });
            }
        };
    }); //Close Factory

}); //Close define